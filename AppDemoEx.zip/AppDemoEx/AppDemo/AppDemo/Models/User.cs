﻿namespace DemoExApp.Models
{
    public class User // Файл User.cs
    {
        public int Id { get; set; }
        public string Role { get; set; }
        public string FullName { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}