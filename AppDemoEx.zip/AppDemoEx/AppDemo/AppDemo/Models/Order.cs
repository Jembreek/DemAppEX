﻿using System;

namespace DemoExApp.Models
{
    public class Order //Файл Order.cs
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int PointId { get; set; }
        public int UserId { get; set; }
        public string Status { get; set; }

        public virtual Point Point { get; set; }
        public virtual User User { get; set; }
    }
}