﻿using System.Data.Entity;

namespace DemoExApp.Models
{
    public class AppDbContext : DbContext // Файл AppDbContext.cs
    {
        public AppDbContext() : base("name=DefaultConnection") { }

        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Point> Points { get; set; }
    }
}