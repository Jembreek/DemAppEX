﻿namespace DemoExApp.Models
{
    public class Point // Файл Point.cs
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}