﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using DemoExApp.Models;

namespace DemoExApp.Pages
{
    public partial class AuthPage : Page
    {
        public AuthPage() { InitializeComponent(); }

        private void AuthButton_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new AppDbContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Login == LoginTextBox.Text && u.Password == PasswordTextBox.Text);
                if (user != null)
                {
                    if (user.Role == "Администратор") NavigationService.Navigate(new AdminPage(user.FullName));
                    else if (user.Role == "Менеджер") NavigationService.Navigate(new ManagerPage(user.FullName));
                    else NavigationService.Navigate(new ClientPage(user.FullName));
                }
                else MessageBox.Show("Неверный логин или пароль");
            }
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new GuestPage());
    }
}