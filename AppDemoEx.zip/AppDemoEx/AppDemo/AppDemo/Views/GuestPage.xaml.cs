﻿using DemoExApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoExApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для GuestPage.xaml
    /// </summary>
    public partial class GuestPage : Page
    {
        public List<Product> _allProducts;

        public GuestPage()
        {
            InitializeComponent();

            LoadProducts();
        }

        void LoadProducts()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    _allProducts = db.Products.ToList();

                    foreach (var product in _allProducts)
                    {
                        if (product.PhotoPath == "")
                            product.PhotoPath = "/Images/picture.png";
                    }
                }

                ProductsListView.ItemsSource = _allProducts.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex}");
            }
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show
                ($"Вы уверены, что хотите выйти?", "Выход из аккаунта", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
                NavigationService.GoBack();
        }
    }
}
