﻿using DemoExApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace DemoExApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Page
    {
        public List<Product> _allProducts;

        public ManagerPage(string fullName)
        {
            InitializeComponent();
            FullNameTextBlock.Text = fullName;

            LoadProducts();
            LoadOrders();
            ApplyFilters();
        }

        void LoadProducts()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    _allProducts = db.Products.ToList();

                    foreach (var product in _allProducts)
                    {
                        if (product.PhotoPath == "")
                            product.PhotoPath = "/Images/picture.png";
                    }
                }

                ProductsListView.ItemsSource = _allProducts.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex}");
            }
        }

        void LoadOrders()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    OrdersListView.ItemsSource = db.Orders
                        .Include(o => o.User)
                        .Include(o => o.Point)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex}");
            }
        }

        void ApplyFilters()
        {
            if (_allProducts == null) return;

            var filterProducts = _allProducts.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(SearchTextBox.Text))
            {
                var searchText = SearchTextBox.Text.ToLower();

                filterProducts = filterProducts.Where(p =>
                p.Name.ToLower().Contains(searchText) ||
                p.Description.ToLower().Contains(searchText) ||
                p.Category.ToLower().Contains(searchText) ||
                p.Manufacturer.ToLower().Contains(searchText) ||
                p.Supplier.ToLower().Contains(searchText) ||
                p.Unit.ToLower().Contains(searchText));
            }

            int supplierIndex = SupplierComboBox.SelectedIndex;

            if (supplierIndex == 0)
                filterProducts = filterProducts.OrderBy(p => p.Name);
            if (supplierIndex == 1)
                filterProducts = filterProducts.Where(p => p.Supplier == "Kari");
            if (supplierIndex == 2)
                filterProducts = filterProducts.Where(p => p.Supplier == "Обувь для вас");

            int quantityIndex = QuantityComboBox.SelectedIndex;

            if (quantityIndex == 0)
                filterProducts = filterProducts.OrderBy(p => p.Quantity);
            if (quantityIndex == 1)
                filterProducts = filterProducts.OrderByDescending(p => p.Quantity);

            ProductsListView.ItemsSource = filterProducts.ToList();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void SupplierComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void QuantityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show
                ($"Вы уверены, что хотите выйти?", "Выход из аккаунта", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
                NavigationService.GoBack();
        }
    }
}
