﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;
using DemoExApp.Models;

namespace DemoExApp.Pages
{
    public partial class AdminPage : Page
    {
        private List<Product> _allProducts;
        public AdminPage(string fullName) { InitializeComponent(); FullNameTextBlock.Text = fullName; LoadData(); }

        private void LoadData()
        {
            using (var db = new AppDbContext())
            {
                _allProducts = db.Products.ToList();
                foreach (var p in _allProducts)
                    if (string.IsNullOrEmpty(p.PhotoPath)) p.PhotoPath = "/Images/picture.png";

                ProductsListView.ItemsSource = _allProducts;
                OrdersListView.ItemsSource = db.Orders.Include(o => o.User).Include(o => o.Point).ToList();
            }
        }

        private void ApplyFilters()
        {
            if (_allProducts == null) return;
            var filter = _allProducts.AsEnumerable();
            if (!string.IsNullOrWhiteSpace(SearchTextBox.Text))
                filter = filter.Where(p => p.Name.ToLower().Contains(SearchTextBox.Text.ToLower()));

            // Твоя логика индексов комбобоксов остается
            if (SupplierComboBox.SelectedIndex == 1) filter = filter.Where(p => p.Supplier == "Kari");
            if (SupplierComboBox.SelectedIndex == 2) filter = filter.Where(p => p.Supplier == "Обувь для вас");

            if (QuantityComboBox.SelectedIndex == 0) filter = filter.OrderBy(p => p.Quantity);
            else if (QuantityComboBox.SelectedIndex == 1) filter = filter.OrderByDescending(p => p.Quantity);

            ProductsListView.ItemsSource = filter.ToList();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();
        private void SupplierComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();
        private void QuantityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();
        private void ExitButton_Click(object sender, RoutedEventArgs e) => NavigationService.GoBack();
    }
}